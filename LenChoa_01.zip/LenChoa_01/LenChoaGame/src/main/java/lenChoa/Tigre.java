package lenChoa;

public class Tigre extends Pe�a{
	
}
