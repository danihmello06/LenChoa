package lenChoa;

public class Posi��o {

	protected boolean livre = true;
}
