package lenChoa;

public class Pe�a {
	
	protected int quantidade;
	
}
