package lenChoa;

public class Tabuleiro {

	protected boolean emJogo = false;
	protected Posi��o posi��es[] = new Posi��o[10];
	protected Tigre pe�aTigre = new Tigre();
	protected Leopardo Leopardo1 = new Leopardo();
	protected Leopardo Leopardo2 = new Leopardo();
	protected Leopardo Leopardo3 = new Leopardo();
	protected Leopardo Leopardo4 = new Leopardo();
	protected Leopardo Leopardo5 = new Leopardo();
	protected Leopardo Leopardo6 = new Leopardo();
	
}
