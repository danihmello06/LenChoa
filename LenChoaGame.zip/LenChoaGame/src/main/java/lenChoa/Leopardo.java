package lenChoa;

public class Leopardo extends Pe�a{

}
