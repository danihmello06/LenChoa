package lenChoa;

public class Jogador {
	
	protected String nome;
	protected boolean tigreLeo;
}
